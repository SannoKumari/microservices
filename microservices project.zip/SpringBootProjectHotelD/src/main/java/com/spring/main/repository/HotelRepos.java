package com.spring.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.main.entity.Hotel;

public interface HotelRepos extends JpaRepository<Hotel , String>{

}
