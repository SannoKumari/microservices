package com.spring.main.service;

import java.util.List;

import com.spring.main.entity.Hotel;

public interface HotelService {
 //create
	public Hotel create(Hotel hotel);
	//get by id
	public Hotel getById(String id);
	// get all
	public List<Hotel> getAll();
}
