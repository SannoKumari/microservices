package com.spring.main.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.main.entity.Hotel;
import com.spring.main.exception.ResourceNotFoundException;
import com.spring.main.repository.HotelRepos;

@Service
public class HotelServiceImp implements HotelService{

	@Autowired
private	HotelRepos repos;
	@Override
	public Hotel create(Hotel hotel) {
		// TODO Auto-generated method stub
		String id = UUID.randomUUID().toString();
		hotel.setId(id);
	return	repos.save(hotel);
		
	}

	@Override
	public Hotel getById(String id) {
		// TODO Auto-generated method stub
	return repos.findById(id).orElseThrow(() -> new ResourceNotFoundException("hotel with given id not found !! "));
		
	}

	@Override
	public List<Hotel> getAll() {
		// TODO Auto-generated method stub
	return	repos.findAll();
		
	}
 
}
