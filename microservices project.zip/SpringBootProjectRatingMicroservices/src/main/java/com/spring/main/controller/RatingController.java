package com.spring.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.main.entity.Rating;
import com.spring.main.service.RatingServiceImp;

@RestController
@RequestMapping("/ratings")
public class RatingController {

	@Autowired
private RatingServiceImp impt;
	
	@PostMapping("/created")
	public ResponseEntity<Rating> createRating(@RequestBody Rating rating) {
		return ResponseEntity.status(HttpStatus.CREATED).body(impt.create(rating));
	}
	
	@GetMapping("/getidbyhotel/{hotelId}")
	public ResponseEntity<List<Rating>> getAllRatingHotel(@PathVariable String hotelId){
		return ResponseEntity.status(HttpStatus.FOUND).body(impt.getRatingByHotelId(hotelId));
	}

	@GetMapping("/getidbyuser/{userId}")
	public ResponseEntity<List<Rating>> getAllRatingUser(@PathVariable String userId){
		return ResponseEntity.status(HttpStatus.FOUND).body(impt.getRatingByUserId(userId));
}

	@GetMapping("/getList")
	public ResponseEntity<List<Rating>> getAllRatingList(){
		return ResponseEntity.status(HttpStatus.FOUND).body(impt.getRating());
		
	}}