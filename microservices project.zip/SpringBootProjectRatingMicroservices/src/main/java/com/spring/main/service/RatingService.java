package com.spring.main.service;

import java.util.List;

import com.spring.main.entity.Rating;

public interface RatingService {
    Rating create(Rating rating);
	List <Rating> getRatingByUserId(String userId);
	List<Rating> getRatingByHotelId(String hotelId);
	List<Rating> getRating();
}
