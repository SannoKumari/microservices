package com.spring.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.spring.main.entity.Rating;
import com.spring.main.repository.RatingRepo;

@Service
public class RatingServiceImp implements RatingService{

	@Autowired
	private RatingRepo rerpo;
	@Override
	public Rating create(Rating rating) {
		// TODO Auto-generated method stub
	return	rerpo.save(rating);
		
	}

	@Override
	public List<Rating> getRatingByUserId(String userId) {
		// TODO Auto-generated method stub
		return rerpo.findByUserId(userId);
	}

	@Override
	public List<Rating> getRatingByHotelId(String hotelId) {
		// TODO Auto-generated method stub
		return rerpo.findByHotelId(hotelId);
	}

	@Override
	public List<Rating> getRating() {
		// TODO Auto-generated method stub
		return rerpo.findAll();
	}

}
