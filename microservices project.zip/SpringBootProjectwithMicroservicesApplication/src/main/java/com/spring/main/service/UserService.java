package com.spring.main.service;

import java.util.List;

import com.spring.main.entity.User;

public interface UserService {

	public User saveUser(User user);
	public List<User> getAllUser();
	
    public User getUser(String userId);
    public User updateUser(String userId);
    
}
