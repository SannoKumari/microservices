package com.spring.main.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.spring.main.entity.Rating;
import com.spring.main.entity.User;
import com.spring.main.exception.ResourceNotFoundException;
import com.spring.main.repository.UserRepository;

@Service
public class UserServiceImp implements UserService{

	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private RestTemplate restTemplate;
	
	private Logger logger = LoggerFactory.getLogger(UserServiceImp.class);
	
	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
	User saveUser=	userRepo.save(user);
		
		return saveUser;
	}

	@Override
	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		List<User> getAll= userRepo.findAll();
		return getAll;
	}

	@Override
	public User getUser(String userId) {
		// TODO Auto-generated method stub
		User user =userRepo.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User with given id not found on server !! : "+userId));
		
		
	ArrayList<Rating> ratingsOfUser = restTemplate.getForObject("http://localhost:8087/ratings/getidbyuser/"+user.getUserId(), ArrayList.class);
	logger.info("{} ", ratingsOfUser);
	
	user.setRatings(ratingsOfUser);
	return user;
	}
	
	@Override
	public User updateUser(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

}
